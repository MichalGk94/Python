for i in range(31):
    if (i%3 != 0):
        print i

