line = "ab cd\t123\nxyz"
L = line.split()
first = ''
last = ''
for i in range(len(L)):
    first = first + L[i][0]
    last = last + L[i][len(L[i])-1]
print first
print last
