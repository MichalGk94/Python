line = "ab cd\t123\nxyz"
L = line.split()
suma = 0
for i in range(len(L)):
    suma += len(L[i])
print suma
