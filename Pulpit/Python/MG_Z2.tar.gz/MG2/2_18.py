liczba = 5840968560980582083092840928540938504398509809238409284200923840023940
zera = 0
liczba_str = str(liczba)
for i in range(len(liczba_str)):
    if liczba_str[i] == "0":
        zera += 1
print zera
