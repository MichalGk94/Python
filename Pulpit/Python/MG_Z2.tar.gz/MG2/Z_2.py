print "Zestaw 2 - Michal Grzeszczak"

print "\nZadanie 2.9"

infile = open("plikin", "r")    #otwarcie pliku do odczytu
outfile = open("plikout", "w")  #otwarcie pliku do zapisu
L = infile.readlines()          #zapis linii do listy

for i in range(len(L)):
    if L[i][0] != "#":
        outfile.write(L[i])
print "Done!"

print "\nZadanie 2.10"

line = "ab cd\t1235\nxyz"
L = line.split()
wyrazy = len(L)
print wyrazy

print "\nZadanie 2.11"

word = "word"
result = word[0]
for i in range(1, len(word)):
    result = result + "_" + word[i]
print result

print "\nZadanie 2.12"

first = ''
last = ''
for i in range(len(L)):
    first = first + L[i][0]
    last = last + L[i][len(L[i])-1]
print first
print last

print "\nZdanie 2.13"

suma = 0
for i in range(len(L)):
    suma += len(L[i])
print suma

print "\nZdanie 2.14"

longest = L[0]
length = len(longest)
for i in range(1, len(L)):
    if len(L[i]) > len(longest):
        longest = L[i]
        length = len(longest)
print longest
print length

print "\nZadanie 2.15"

M = [25, 36, 49, 64]
wyraz = ''
for i in range(len(M)):
    wyraz = wyraz + str(M[i])
print wyraz

print "\nZdanie 2.16"

gfile = open("gvr", "r")
text = gfile.read()
newline = text.replace("GvR", "Guido van Rossum")
print newline

print "\nZadanie 2.17"

print sorted(line.split(), key = str.lower)
print sorted(line.split(), key = len)

print "\nZadanie 2.18"

liczba = 5840968560980582083092840928540938504398509809238409284200923840023940
zera = 0
liczba_str = str(liczba)
for i in range(len(liczba_str)):
    if liczba_str[i] == "0":
        zera += 1
print zera

print "\nZadanie 2.19"

N = [1, 12, 7, 365, 2, 41, 100]
napis = ''
for i in range(len(N)):
    napis = napis + str(N[i]).zfill(3)
print napis
