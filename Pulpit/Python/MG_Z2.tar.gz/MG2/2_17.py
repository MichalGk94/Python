line = "ab cd\t1235\nxyz"
print sorted(line.split(), key = str.lower)
print sorted(line.split(), key = len)
