L = [1, 12, 7, 365, 2, 41, 100]
napis = ''
for i in range(len(L)):
    napis = napis + str(L[i]).zfill(3)
print napis
