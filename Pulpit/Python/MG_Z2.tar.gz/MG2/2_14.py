line = "ab cd\t1235\nxyz"
L = line.split()
longest = L[0]
length = len(longest)
for i in range(1, len(L)):
    if len(L[i]) > len(longest):
        longest = L[i]
        length = len(longest)
print longest
print length
