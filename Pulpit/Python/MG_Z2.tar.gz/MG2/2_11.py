line = "word"
result = line[0]
for i in range(1, len(line)):
    result = result + "_" + line[i]
print result
