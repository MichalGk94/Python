line = "ab cd\t123\nxyz"
L = line.split()
wyrazy = len(L)
print wyrazy
