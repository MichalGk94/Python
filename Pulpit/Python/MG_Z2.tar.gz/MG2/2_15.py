L = [25, 36, 49, 64]
wyraz = ''
for i in range(len(L)):
    wyraz = wyraz + str(L[i])
print wyraz
