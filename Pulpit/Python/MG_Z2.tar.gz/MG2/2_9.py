infile = open("plikin", "r")    #otwarcie pliku do odczytu
outfile = open("plikout", "w")  #otwarcie pliku do zapisu
L = infile.readlines()          #zapis linii do listy

for i in range(len(L)):
    if L[i][0] != "#":
        outfile.write(L[i])
