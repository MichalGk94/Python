gfile = open("gvr", "r")
line = gfile.read()
newline = line.replace("GvR", "Guido van Rossum")
print newline
